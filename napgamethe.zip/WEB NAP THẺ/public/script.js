document.getElementById("napForm").addEventListener("submit", function(e) {
  e.preventDefault(); // Không reload trang

  const game_id = document.getElementById("game_id").value;
  const server = document.getElementById("server").value;
  const telco = document.getElementById("telco").value;
  const amount = document.getElementById("amount").value;
  const serial = document.getElementById("serial").value;
  const code = document.getElementById("code").value;

  fetch("/api/send-card", {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify({
      game_id,
      server,
      telco,
      amount,
      serial,
      code
    })
  })
  .then(res => res.json())
  .then(data => {
    if (data.ok) {
      alert("Gửi thành công!");
    } else {
      alert("Lỗi: " + (data.message || "Không gửi được"));
    }
  })
  .catch(err => {
    console.error(err);
    alert("Lỗi kết nối server");
  });
});